#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <map>
#include <queue>
#include <algorithm>
#include <sstream>

#define INF 0x3f3f3f3f
#define MAX_N 100001
#define MAX_E 300001

using namespace std;

struct edge
{
    int u;//Ȩֵ
    int v;//�ߵ��յ�
    int next;//��һ����
}e[MAX_E];

int head[MAX_N];
string Bus_Name[1000];//������������
int dist[MAX_N];
map <string,vector<int>> stop_to_node;//����վ̨�ϻ�·�������й������ı��

struct Stop
{
    string name;
    int bus_num;
    Stop(string _name,int ID)
    //���캯��
    {
        name = _name;
        bus_num = ID;
    }
};

vector <Stop> bus_stops;
vector <int> bus_to_stop[1000];
int bus_num, stop_num, cnt;
//stop_numָͣ����վ̨�ڸ�·���еĴ��򣨱�ţ�
//bus_numָ�������ı��
//cntָ

vector <string> split(string& str,const char space = ' ')
//��һ���ַ������ո�split
{
    istringstream sstr(str);
    vector <string> result;
    string tmp;
    while(getline(sstr,tmp,space))
    {
        result.push_back(tmp);
    }
    return result;

}

void Read_file()
{
    bus_stops.push_back(Stop("",0));
    ifstream file("./routine.txt");
    if(file.fail())
    {
        cout << "�ļ���ʧ��!!!" << endl;
		exit(EXIT_FAILURE);
    }
    while(!file.eof())
    {
        ++bus_num;
        char tmp[3000];
        string bus_name,str;
        file>>bus_name;
        if(file.fail())
        {
            bus_num--;
            break;
        }
        file.getline(tmp,3000);
        str = string(tmp);
        vector <string> stops = split(str);
        Bus_Name[bus_num] = bus_name;
        for(int i=0;i<stops.size();++i)
        {
            stop_num++;
            bus_to_stop[bus_num].push_back(stop_num);
            //��i·������ͣ����վ̨�ı�Ŵ�������
            bus_stops.push_back(Stop(stops[i],bus_num));
            //��ʾ��վ̨��i·����������
            stop_to_node[stops[i]].push_back(stop_num);
            //��Ӧĳ��վ̨��ĳ����������·���еľ������
        }
    }
}

void addedge(int u,int v,int w)
{
    ++cnt;
    e[cnt].u = u;
    e[cnt].v = v;
    e[cnt].next = head[w];
    head[w] = cnt;
}

void add_all_edge()
{
    for(int i=1;i<=bus_num;++i)
    {
        for(int j=0;j<bus_to_stop[i].size()-1;++j)
        {
            addedge(bus_to_stop[i][j],bus_to_stop[i][j+1],1);
            addedge(bus_to_stop[i][j],bus_to_stop[i][j+1],1);
        }
    }
    for(auto nodes:stop_to_node)
    {
        vector<int>::iterator it;
        for(it=nodes.second.begin();it!=nodes.second.end();++it)
        {
            addedge(*it,*(it+1),0);
            addedge(*(it+1),*it,0);
        }
    }
}

void print_all_path()
{
    for(int i=1;i<=stop_num;++i)
    {
        cout<<Bus_Name[bus_stops[i].bus_num]<<":"<<endl;
        cout<<"���ɴ��վ����:"<<endl;
        for(int j=head[i];j;j=e[j].next)
        {
            cout<<Bus_Name[bus_stops[e[j].v].bus_num]<<"�ϵ�"<<bus_stops[e[j].v].name<<",ȨֵΪ:"<<e[j].u<<endl;

        }
        cout<<endl;
    }
}

pair<int,int> dijkstra(string start,string end,int *path,int type)
{
    int path_all[MAX_E];
    int min = INF;
    int end_all = -1;
    int s_all = -1;
    for(int k=0;k<stop_to_node[start].size();++k)
    {
        int s = stop_to_node[start][k];
        for(int j=0;j<MAX_N;++j)
        {
            dist[j] = INF;
        }
        bool visit[MAX_N];
        memset(visit,0,sizeof(visit));
        struct node
        {
            int u,dis;
            bool operator <(const node& rhs) const
            {
                return dis>rhs.dis;
            }
        };
        priority_queue <node> Q;
        dist[s] = 0;
        Q.push(node{s,0});
        while(!Q.empty())
        {
            node fnt = Q.top();
            Q.pop();
            int u = fnt.u;
            int dis = fnt.dis;
            visit[u] = true;
            for(int i=head[u];i;i=e[i].next)
            {
                int v = e[i].v;
                int w = e[i].u;
                if(type==1)
                {
                    w = 1-w;
                }
                if(dist[v]>dist[u]+w && !visit[v])
                {
                    path[v] = u;
                    dist[v] = dist[u] + w;
                    Q.push(node{v,dist[v]});
                }
            }
        }
        int min_dist = INF;
        int end_tmp;
        for(int j=0;j<stop_to_node[end].size();++j)
        {
            if(min_dist>dist[stop_to_node[end][j]])
            {
                min_dist = dist[stop_to_node[end][j]];
                end_tmp = stop_to_node[end][j];
            }
        }
        if(min>min_dist)
        {
            for(int i=0;i<MAX_E;++i)
            {
                path_all[i] = path[i];
            }
            end_all = end_tmp;
            s_all = s;
        }
    }
    for(int i=0;i<MAX_E;++i)
    {
        path[i] = path_all[i];
    }
    return make_pair(s_all,end_all);
}

void TASK(string start,string end,int type)
{
    int *path = new int[MAX_E];
    pair<int,int> result;
    result = dijkstra(start,end,path,type);
    int end_pos = result.second;
    if(end_pos == -1)
    {
        cout<<"��Ǹ����ʱû���ҵ�����Ҫ����·"<<endl;
        return ;
    }
    vector <Stop> stops;
    int t = end_pos;
    while(bus_stops[t].name != start)
    {
        stops.push_back(bus_stops[t]);
        t = path[t];//����
    }
    reverse(stops.begin(),stops.end());
    cout<<"��"<<start<<"��ʼ"<<endl;
    cout<<"����"<<Bus_Name[stops[0].bus_num];
    int sum_transfor=0, sum_pass=0;
    for(int i=0;i<stops.size();++i)
    {
        if(i && stops[i].bus_num != stops[i-1].bus_num)
        {
            if(i+1<stops.size()&&stops[i].name!=stops[i+1].name)
            {
                cout<<endl<<"ת��"<<Bus_Name[stops[i-1].bus_num];
                sum_transfor ++;
            }
            
        }
        else
        {
            sum_pass++;
            cout<<"->"<<stops[i].name<<" ";
        }
        if(stops[i].name==end)
        {
            break;
        }
    }
    cout<<endl<<"��;������"<<sum_pass<<"��վ̨��ת��"<<sum_transfor<<"��"<<endl;
}

int main()
{
    cout<<"���濪ʼ�����ļ���"<<endl;
    Read_file();
    add_all_edge();
    cout<<"�ļ������Ҵ洢�ɹ���"<<endl;
    print_all_path();
    string start,end;
    bool flag = true;
    while(flag)
    {
        cout<<"��������Ҫ��ѯ�������յ�:"<<endl;
        cin>>start>>end;
        if(!stop_to_node[start].size())
        {
            cout<<"�������������������롣"<<endl;
        }
        else if(!stop_to_node[end].size() || start==end)
        {
            cout<<"�յ�����������������롣"<<endl;
        }
        else
        {
            flag = false;
        }
    }
        cout<<"����������·��:"<<endl;
        TASK(start,end,0);
        system("pause");
        system("cls");
        cout<<"���������С����·��:"<<endl;
        TASK(start, end, 1);
        system("pause");
        system("cls");
    return 0;
}