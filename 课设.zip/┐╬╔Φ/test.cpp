#include <iostream>
#include <string.h>
#include <string>
#include <algorithm>
#include <set>
#include <queue>
#include <vector>
#include <sstream>
#include <iomanip>
#include <map>
#include <math.h>
using namespace std;

typedef pair<int,int> P;

bool cmp(char &a,char &b)
{return a<b;}

vector <string> split(string& str,const char space = ' ')
//��һ���ַ������ո�split
{
    istringstream sstr(str);
    vector <string> result;
    string tmp;
    while(getline(sstr,tmp,space))
    {
        result.push_back(tmp);
    }
    return result;

}

struct Node
{
    string s;
    int a;
};

int main()
{
    
    int a = 3*pow(2,6);
    int b = 3<<6;
    cout<<a<<" "<<b;
    return 0;
}