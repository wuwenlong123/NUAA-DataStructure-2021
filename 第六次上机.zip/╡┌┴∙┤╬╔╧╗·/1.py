import tensorflow as tf
import tensorflow_datasets as tfds

ds = tfds.load('goemotions',split='train')