#include<iostream>
typedef long long ll;  //用long long
using namespace std;
int main()
{
    ll r,y,g;
	cin>>r>>y>>g;
	ll n;
    ll mod = r+y+g;//等待时间的模长
	cin>>n;
    ll sum=0;//经历的总时间
	ll cur;//代表走到路口时的时间
	while(n--)
	{
		int k,t;
		cin>>k>>t;
        if(k==0)
        //走过当前路段
		{
			sum+=t;
		    continue;
		}
        else
        {
            switch(k)
            //计算当前时间在mod时间里的长度。
            {
                case 1:
                    cur = (sum+r-t)%mod;
                    break;
                case 2:
                    cur =(sum+mod-t)%mod;
                    break;
                case 3:
                    cur = (sum+r+g-t)%mod;
            }
        }
		if(cur>0 && cur<r)
		{
			k = 1;
			t=r-cur;
		}
		if(cur>=r && cur<r+g)
		{
			k = 3;
			t = r+g-cur;
		}
	    if(cur>=r+g && cur<r+g+y)
		{
			k = 2;
			t = r+g+y-cur;
		}
        switch(k)
        {
            case 1:
                sum+=t;
                break;
            case 2:
                sum+=(r+t);
                break;
            case 3:
                break;
        }
	}
	cout<<sum<<endl;
}