#include <iostream>
using namespace std;

typedef struct row
{
    int seat[5];
    int num;
};

void Inseat(row *Row,int j,int &temp,int n)
//入座函数，指定行座位Row，指定排数j，需求票数temp，标记为n
{
    for(int s=0;s<5;++s)
    {
        if(temp==0) break;
        if(Row[j].seat[s]==0)
        {
            Row[j].seat[s] = n;
            --temp;
            --Row[j].num;
        }
    }
}

int main()
{
    int n;
    cin>>n;
    row *Row = new row[20];
    for(int i=0;i<20;++i)
    //初始化座位数组
    {
        Row[i].seat[0] = 0;
        Row[i].seat[1] = 0;
        Row[i].seat[2] = 0;
        Row[i].seat[3] = 0;
        Row[i].seat[4] = 0;
        Row[i].num = 5;
    }
    for(int zz=1;zz<=n;++zz)
    //对n个要买票的人，我们分别给它们的座位标记上1-n
    {
        int temp;//票数
        cin>>temp;
        int j=0;
        for(;j<20;++j)
        //先遍历所有座位，找出能够连在一起占座的情况。
        {
            if(Row[j].num>=temp)
            {
                Inseat(Row,j,temp,zz);
            }
        }
        if(temp!=0)
        //如果已经没有座位能够连在一起了，即temp还不为0，需要遍历所有的剩余座位直到temp为0
        {
            for(int y=0;y<20;++y)
            {
                int tt=Row[y].num;
                Inseat(Row,y,tt,zz);
                temp -= tt;
                if(temp==0) break;
            }
        }
    }
    for(int k=1;k<=n;++k)
    //根据座位的编号，输出所有的订票情况。
    {
        for(int m=0;m<20;++m)
        {
            for(int x=0;x<5;++x)
            {
                if(Row[m].seat[x]==k)
                {
                    cout<<5*m+x+1<<" ";
                }
            }
        }
        cout<<endl;
    }
    return 0;
}