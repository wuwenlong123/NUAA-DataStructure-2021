#include <iostream>
#include <stdlib.h>
#include <algorithm>

using namespace std;
#define MAXSIZE 256
typedef int T;

typedef struct
{
    int i,j;
    T value;
}Triple;

typedef struct
{
    Triple arr[MAXSIZE];
    int Rows,Cols,Nums;//���������ͷ���Ԫ�ظ���
}SqMatrix;

void CreatMatrix(SqMatrix &M)
{
    cout<<"�����������к��У�";
    int rows,cols;
    cin>>rows>>cols;
    if(rows>16 || cols>16) {cout<<"Error��������Խ�磡"<<endl;return;}
    int temp;
    M.Cols = cols;
    M.Rows = rows;
    int count = 0;
    cout<<"��������Щֵ��"<<endl;
    for(int i=0;i<rows;++i)
    {
        for(int j=0;j<cols;++j)
        {
            cin>>temp;
            if(temp != 0)
            {
                M.arr[count].i = i;
                M.arr[count].j = j;
                M.arr[count++].value = temp;
            }
        }
    }
    M.Nums = count;
    cout<<"�����Ѵ洢��ϣ�"<<endl;
}

void TransposeMatrix(SqMatrix A, SqMatrix &B)
{
    B.Rows = A.Cols;
    B.Cols = A.Rows;
    B.Nums = A.Nums;
    if(A.Nums>0)
    {
        int q=0;//B.arr�ĵ�ǰλ��
        for(int k=0;k<A.Cols;++k)
        {
            for(int p=0;p<A.Nums;++p)
            {
                if(A.arr[p].j == k)//����p����Ԫ���Ԫ�ص��к�Ϊk
                {
                    B.arr[q].i = A.arr[p].j;
                    B.arr[q].j = A.arr[p].i;
                    B.arr[q++].value = A.arr[p].value;
                }
            }
        }
    }
    cout<<"ת����ϣ�"<<endl;
}

void PrintMatrix(SqMatrix A)
{
    int count = 0;
    for(int i=0;i<A.Rows;++i)
    {
        for(int j=0;j<A.Cols;++j)
        {
            if(A.arr[count].i==i && A.arr[count].j==j)
            {
                cout<<A.arr[count++].value<<" ";
            }
            else
            {
                cout<<"0 ";
            }
        }
        cout<<endl;
    }
}

void FastTransposeMatrix(SqMatrix A,SqMatrix &B)
{
    B.Rows = A.Cols;
    B.Cols = A.Rows;
    B.Nums = A.Nums;
    int *rowNum = new int[A.Cols];
    int *rowStart = new int[A.Cols];
    for(int s=0;s<A.Cols;++s) rowNum[s] = 0;
    for(int i=0;i<A.Nums;++i) ++rowNum[A.arr[i].j];//ͳ��A��ÿ�з�����ĸ���
    rowStart[0] = 0;
    for(int k=1;k<A.Cols;++k)
    {
        rowStart[k] = rowStart[k-1] + rowNum[k-1];//B��ÿ�е���Ԫ�����ʼλ��
    }
    for(int p=0;p<A.Nums;++p)
    {
        int q;
        q = rowStart[A.arr[p].j]++;
        B.arr[q].i = A.arr[p].j;
        B.arr[q].j = A.arr[p].i;
        B.arr[q].value = A.arr[p].value;
    }
}

int main()
{
    SqMatrix A,Tran_A,FastTran_A;
    CreatMatrix(A);
    TransposeMatrix(A,Tran_A);
    PrintMatrix(A);
    cout<<"ת�ú�ľ���Ϊ��"<<endl;
    PrintMatrix(Tran_A);
    cout<<"������ÿ���ת���㷨��"<<endl;

    cout<<"ת�ú�ľ���Ϊ��"<<endl;
    FastTransposeMatrix(A,FastTran_A);
    PrintMatrix(FastTran_A);
    return 0;
}