#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

#define MAXN 1000000

int timeblock[MAXN];
int k[MAXN];

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL),cout.tie(NULL);
    int n;
    cin>>n;
    int x,y;
    memset(timeblock,0,MAXN);
    for(int i=1;i<=2*n;++i)
    //输入两个人的时间段，初试时间点设为1，结束时间点设为-1
    {
        cin>>x>>y;
        k[x]++;//一个人开始工作
        k[y]--;//一个人结束工作
    }
    int count = 0;
    for(int i=1;i<MAXN;++i)
    {
        timeblock[i] = timeblock[i-1]+k[i];//差分开始累加
        if(timeblock[i]==2) count++;
    }
    cout<<count<<endl;
    return 0;
}