import matplotlib.pyplot as plt

plt.plot