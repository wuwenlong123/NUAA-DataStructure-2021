#include <iostream>
#include <algorithm>
using namespace std;

typedef struct Node
{
    int data;
    struct Node* next;
}Node;

Node* Inicitate(int x)
{
    Node *L = new Node;
    if(L == NULL)
    {
        cout<<"Error!No enough memory!"<<endl;
        return NULL;
    }
    else
    {
        L->data = x;
        L->next = NULL;
        //cout<<"����ɹ���"<<endl;
        return L;
    }
}

Node* GetElem(int n)
{
    Node* head = new Node;
    head->data = 1;
    head->next = NULL;
    Node* p = head;
    for(int i=2;i<=n;++i)
    {
        Node *tmp = Inicitate(i);
        p->next = tmp;
        p = p->next;
    }
    p->next = head;
    cout<<"ѭ������������ϣ�"<<endl;
    return head;
}

void Josephus(Node* L,int m)
{
    Node* tail = L;
    while(tail->next != L)
    {
        tail=tail->next;
    }//tailΪβָ�룬��L����һ��ָ��
    Node* p = L;
    while(p->data!=1)
    {
        tail = p;
        p = p->next;
    }//�ҵ����Ϊ1����
    while(p->next!=p)//������ֻʣ��һ���ڵ�ʱֹͣ
    {
        for(int i=1;i<m;++i)
        {
            tail = p;
            p = p->next;
        }
        cout<<p->data<<"->";
        tail->next = p->next;//�Ƴ��ڵ�p
        free(p);
        p = tail->next;
    }
    cout<<p->data;
    free(p);
}

int main()
{
    int m,n;
    cout<<"������n��m��";
    cin>>n>>m;
    Node* L = GetElem(n);
    Josephus(L,m);
    return 0;
}