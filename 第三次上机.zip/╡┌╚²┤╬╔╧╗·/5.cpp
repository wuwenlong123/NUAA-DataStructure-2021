#include <iostream>
#include <stdlib.h>
#include <algorithm>
using namespace std;

struct click
//��¼һ�ε���������
{
    int x;
    int y;
}Click[10];

typedef struct windows
{
    int x1;
    int x2;
    int y1;
    int y2;
    int num;//���ڱ��
    struct windows* next;
}windows;

windows* creat_list(int N)
{
    windows *L=(windows*)malloc(sizeof(windows));//����һ��ͷ���
    windows* temp = L;//����һ��ָ��ָ��ͷ��㣬���ڱ�������
    //��������
    for (int i=0; i<N; i++) 
    {
        windows *a=(windows*)malloc(sizeof(windows));
        int x1,x2,y1,y2;
        cin>>x1>>y1>>x2>>y2;
        a->x1 = x1;
        a->x2 = x2;
        a->y1 = y1;
        a->y2 = y2;
        a->num = i+1;
        a->next=NULL;
        temp->next=a;
        temp=temp->next;
    }
    return L;
}


windows* Reverse(windows *L)
//����
{
    windows *p = L->next;
    L->next = NULL;
    while(p)
    {
        windows *q = p;
        p = p->next;
        q->next = L->next;
        L->next = q;
    }
    return L;
}

void print(windows *L)
{
    windows *p = L->next;
    while(p)
    {
        cout<<p->x1<<" "<<p->y1<<" "<<p->x2<<" "<<p->y2<<endl;
        p = p->next;
    }
}

void Modify(windows* L,int t)
{
    if(t==1) return;
    else
    {
        windows* cur = L->next;
        windows* pre = L;
        for(int i=0;i<t-1;++i)
        {
            pre = pre->next;
            cur = cur->next;
        }
        pre->next = cur->next;
        windows* tmp = L->next;
        L->next = cur;
        cur->next = tmp;
    }
}

void Check(windows *L,int k)
{
    windows *p = L->next;
    int x = Click[k].x;
    int y = Click[k].y;
    int t = 1;
    while(p)
    {
        if(x>=p->x1 && x<= p->x2 && y>=p->y1 && y<=p->y2)
        {
            cout<<p->num<<endl;
            Modify(L,t);//������Ĵ��ڲ����ͷ
            return;
        }
        p = p->next;
        ++t;
    }
    cout<<"IGNORED"<<endl;
}

int main()
{
    int N,M;
    cin>>N>>M;
    windows *L;
    L = creat_list(N);
    //cout<<"�����Ѵ�����"<<endl;
    Reverse(L);//��������
    //cout<<"���������ã�"<<endl;
    for(int i=0;i<M;++i)
    {
        int x,y;
        cin>>x>>y;
        Click[i].x = x;
        Click[i].y = y;
    }
    //print(L);cout<<endl<<endl;
    for(int k=0;k<M;++k)
    {
        Check(L,k);
    }
    return 0;
}