#include <iostream>
#include <stdlib.h>
#include <algorithm>
using namespace std;

#define MAXSIZE 100000

struct student
{
    int y;//��ȫָ��
    bool result;//�ҿƽ��
}stu[MAXSIZE];

bool predict(int y,int line)
{
    return y>=line;
}

int Value(int line,int num)
{   
    int sum=0;
    for(int i=0;i<num;++i)
    {
        if(predict(stu[i].y,line) == stu[i].result) ++sum;
    }
    cout<<"ֵΪ"<<line<<"ʱ����ȷ����Ϊ��"<<sum<<endl;
    return sum;
}

int main()
{
    int m;
    cin>>m;
    for(int i=0;i<m;++i)
    {
        cin>>stu[i].y>>stu[i].result;
    }
    int ans = 0;
    int value = 0;
    for(int j=0;j<m;++j)
    {
        int line = stu[j].y;
        int x = Value(line,m);
        if(x >= value)
        {
            ans = line;
            value = x;
        }
    }
    cout<<ans<<endl;
    return 0;
}