#include <iostream>
#include <algorithm>
#include <cstring>
#include <math.h>
using namespace std;
#define MAXSIZE 256

struct ball
{
    int location=0; //小球位置，初始化为0
    int collision;  //小球碰撞的次数
}a[MAXSIZE]; //小球数组，只利用n个空间。

int main()
{
    std::ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int n,L,t;
    cin>>n>>L>>t;
    for(int i=1;i<=n;++i)
    {
        cin>>a[i].location;//输入小球的初始位置
        a[i].collision = 0;
    }
    for(int i=1;i<=t;++i)
    {
        for(int j=1;j<=n;++j)
        {
            a[j].location += pow(-1,a[j].collision);//将小球位置进行一个时间单位的挪动，碰撞奇数次速度就是-1，偶数次就是1.
            if(a[j].location==L || a[j].location==0)//判断小球是否碰壁
                a[j].collision++;
        }
        for(int x=1;x<n;++x)
        {
            for(int y=x+1;y<=n;++y)//判断两个小球是否相撞
            {
                if(a[x].location==a[y].location)
                {
                    ++a[x].collision;
                    ++a[y].collision;
                }
            }
        }  
    }
    for(int k=1;k<=n;++k)//输出小球最终位置
    {
        cout<<a[k].location<<" ";
    }
}