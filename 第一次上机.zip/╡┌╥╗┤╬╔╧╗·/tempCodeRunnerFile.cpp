#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

#define  MAXSIZE 100     //最大长度
typedef int ElemType; 
typedef  struct {
  ElemType  *elem;     //指向数据元素的起始地址
  int  length;          //线性表的当前长度                                                      
 }SqList; 
 
 void SL_Initiate(SqList &L)
// 顺序表的初始化，即构造一个空的顺序表
{
	L.elem = (ElemType*)malloc(sizeof(ElemType)*MAXSIZE);
	L.length=0;
}

void SL_Free(SqList &L)
// 释放顺序表
{
	free(L.elem);
}

bool SL_IsEmpty(SqList L)
// 判断顺序表是否空
{
	return L.length==0;
}

bool SL_IsFull(SqList L)
// 判断顺序表是否满
{
	return L.length==MAXSIZE;
}

void SL_Create(SqList &L,int n)
// 输入n个数据元素，创建一个顺序表L
{
	int i;
	L.length=n;
	for(i=0; i<n; i++)
		scanf("%d", &L.elem[i]);		
}

void SL_Print(SqList L)
// 输出整个顺序表
{
	if (L.length==0)
	{
		printf("The slist is empty.\n");		
		return;
	}

	for (int i=0; i<L.length; i++)
		printf("%d  ", L.elem[i]);
	printf("\n");	
}


int ListLength(SqList L) 
{
    return L.length;
}

void SL_GetAt(SqList L, int i, ElemType &e)
// 获取顺序表L的第i个元素赋给e，i的有效范围[1,L.length]。
{
	if(i>=1 && i<=L.length)
	{
		e = L.elem[i-1];
	}
}

int SL_FindValue(SqList L, ElemType x)
// 在顺序表L中查找第一个值为x的元素，找到则返回该元素在表中的位置，否则返回0。
{
	for(int i=0;i<L.length;++i)
	{
		if(L.elem[i]==x) 
		{
			printf("已找到这个元素！\n");
			return i+1;
		}
		
	}
	printf("未找到这个元素！\n");
	return 0;
}

void SL_InsAt(SqList &L, int i, ElemType e)
// 在顺序表的第i个位置插入新元素e, 即在元素L.elem[i-1]之前插入
// i的有效范围[1,L.length+1]
{
	if(i>=1 && i<=L.length+1)
	{
		
		for(int j=L.length;j>i-1;--j)
		{
			L.elem[j] = L.elem[j-1];
		}
		L.elem[i-1] = e;
		L.length++;
	}
}

void SL_DelAt(SqList &L, int i)
// 删除顺序表L的第i个元素
//i的有效范围[1,L.length]
{
	if(i>=1 && i<=L.length)
	{
		for(int j=i-1;j<L.length-1;++j)
		{
			L.elem[j] = L.elem[j+1];
		}
		L.length--;
		printf("删除成功！\n");
	}
	else
	{
		printf("删除失败！\n");
	}
}

//删除表中重复元素 
void SL_DelRepeatedElm(SqList &L)
{
    int j=1,i=0,len=1;
    while(j<L.length)
    {
        for(i=0;i<len;++i)//和已经进入的不重复集合的元素进行比较 
        {
            if(L.elem[i]==L.elem[j])
                break;
    	}
        if(i==len)//意味着上面的for循环是正常结束的，所有没重复，可以进入不重复集合 
            L.elem[len++]=L.elem[j++];
        else
            j++;//说明出现重复元素，j++，判断下一个元素 
    }
    L.length=len;//最后不充分数组的长度就是，进入该数组的个数 
}

void SL_DelValue(SqList &L, ElemType x)
// 删除第一个值为x的元素
{
	int i=0;
	bool flag = false;
	for(;i<L.length;++i)
	{
		if(L.elem[i] == x){flag = true;break;}
	}
	if(flag) {SL_DelAt(L, i+1);
	printf("删除成功！\n");
	}
	else printf("删除失败！\n"); 
}

//翻转顺序表 
void SL_Reverse(SqList &L)  
{
	ElemType temp;
	int i;
	for(i=0;i<(L.length)/2;i++)
	{
		temp=L.elem[i];
		L.elem[i]=L.elem[L.length-1-i];
		L.elem[L.length-1-i]=temp;
	}
}

//排序表
void SL_Sort(SqList &L) 
{
	int n=L.length;
	ElemType temp;
	for(int i = 0;i<n-1;i++)
	{
		for(int j = 0;j< n-1-i;j++)
		{
			if(L.elem[j+1]<L.elem[j])
			{
				temp = L.elem[j];
				L.elem[j] = L.elem[j+1];
				L.elem[j+1] = temp;
			}
		}
		++i;
	}
}

int main()
{
	SqList L;int n,i,x;
	
	SL_Initiate(L);
	printf("链表已初始化！\n");
	printf("请输入元素的个数：");
	scanf("%d", &n);//输入元素的个数
	SL_Create(L, n);
	
	printf("请输入待获取元素的位置：");
	scanf("%d", &i);//输入待获取元素的位置
	int element,location;
	SL_GetAt(L, i, element);
	printf("它的值为：%d\n",element);
	 
	printf("请输入待查找元素的值：");
	scanf("%d", &x);//输入待查找元素的值
	location=SL_FindValue(L, x);
	printf("该元素的位置为：%d\n",location);
	
	printf("请输入待插入的位置和元素的值：");
	scanf("%d%d", &i,&x);//输入待插入的位置和待插入元素的值
	SL_InsAt(L, i, x);
	printf("插入后的顺序表为：");
	SL_Print(L); 

	printf("请输入待删除的元素的位置:");	
	scanf("%d", &i);//输入待删除元素的位置
	SL_DelAt(L, i);
	printf("删除后的顺序表为：");
	SL_Print(L); 

	printf("请输入待删除的元素的值：");
	scanf("%d", &x);//输入待删除元素的值
	SL_DelValue(L, x);
	printf("删除后的顺序表为：");
	SL_Print(L); 
	
	printf("下面删除顺序表中重复的元素。\n");
	SL_DelRepeatedElm(L);
	printf("删除后的顺序表为：");
	SL_Print(L); 
	
	printf("下面翻转顺序表。\n");
	SL_Reverse(L);
	printf("翻转后的顺序表为：");
	SL_Print(L); 
	
	printf("下面排序表。\n");
	SL_Sort(L);
	printf("升序排序后的表为：");
	SL_Print(L);	
	SL_Free(L);
}


