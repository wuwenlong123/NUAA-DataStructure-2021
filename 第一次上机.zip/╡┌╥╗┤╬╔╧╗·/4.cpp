#include<iostream>
#include<cstring>
using namespace std;

#define MAXSIZE 256

int a[MAXSIZE];

int main()
{
    //解放C++的IO流与printf，scanf的捆绑关系
    std::ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    //初始化数组a为0
    memset(a,0,sizeof(a));
    int n,m,l;
    cin>>n>>m>>l;
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<=m;++j)
        {
            //将输入的值作为数组a的下标，统计每个值出现的次数
            int x;
            cin>>x;
            ++a[x];
        }
    }
    for(int i=0;i<l;++i)
    {
        //输出每个值出现的次数
        cout<<a[i]<<" ";
    }
    cout<<endl;

}