#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    int i=0;
    int *p = &i;
    *p = 10;
    cout<<i<<endl;
    return 0;
}