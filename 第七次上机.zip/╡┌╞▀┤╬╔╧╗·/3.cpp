#include <iostream>
#include <algorithm>
using namespace std;

bool drop[1001] = {false};//苹果树最终是否掉落

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL),cout.tie(NULL);
    int N,m,count=0;
    long sum = 0;
    cin>>N;
    for(int i=1;i<=N;++i)
    {
        int num;
        cin>>m;
        cin>>num;//初始个数
        for(int j=0;j<m-1;++j)
        {
            long tmp;
            cin>>tmp;
            if(tmp<=0)
            {
                num += tmp;
            }
            else if(num != tmp)//如果有苹果掉落
            {
                drop[i] = true;
                num = tmp;
            }
        }
        if(drop[i]) ++count;
        sum += num;  
    }
    int three = 0;
    for(int i=1;i<=N-2;++i)
    {
        if(drop[i] && drop[i+1] && drop[i+2])
        {
            ++three;
        }
    }
    if(drop[N-1] && drop[N] && drop[1]) ++three;
    if(drop[N] && drop[1] && drop[2]) ++three;
    cout<<sum<<" "<<count<<" "<<three;
    return 0;
}