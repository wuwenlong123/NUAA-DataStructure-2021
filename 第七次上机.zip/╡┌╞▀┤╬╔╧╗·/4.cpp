#include <iostream>
#include <algorithm>
using namespace std;

#define M 100001

struct Graph
{
    int u,v;
    int weight;
}G[M];

int father[M];
int n,m;

bool cmp(Graph a,Graph b)
{
    return a.weight<b.weight;
}

int find(int x)
{
    int a=x;
    while(x != father[x])
    {
        x = father[x];
    }
    return x;
}

void unite(int x,int y)
{
    father[find(x)] = find(y);
}

int kruskal(int n,int m)
{
     int sum = 0;//权值
     int count = 0;//归并的边的个数
     for(int i=0;i<m;++i)
     {
        if(find(G[i].u) != find(G[i].v))
        {
            unite(G[i].u,G[i].v);
            sum += G[i].weight;
            ++count;
            if(count == n-1) break;
        } 
     }
     if(count == n-1) return sum;
     else return -1;//图不连通
}

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(0),cout.tie(0);
    cin>>n>>m;
    for(int i=0;i<m;++i)
    {
        cin>>G[i].u>>G[i].v>>G[i].weight;
    }
    sort(G,G+m,cmp);
    for(int i=0;i<n;++i)
    {
        father[i] = i;//初始化
    }
    int ans = kruskal(n,m);
    if(ans != -1) cout<<ans;
    return 0;
}