
    Path(G,path[v]);