#include <iostream>
#include <algorithm>
using namespace std;

typedef long long ll;
#define N 1005

struct position
{
    ll x;
    ll y;
};

bool cmp(position a,position b)
{
    return a.x<b.x;
}

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(0),cout.tie(0);
    int n;
    int ans[5] = {0};
    cin>>n;
    position pos[N];
    for(int i=0;i<n;++i)
    {
        cin>>pos[i].x>>pos[i].y;
    }
    int x=0,y=0;//x记录上下左右，y记录四个角
    sort(pos,pos+n,cmp);
    for(int i=0;i<n;++i)
    {
        x=0;y=0;
        for(int j=0;j<n;++j)
        {
            if(j==i) continue;
            if(
                (pos[i].x==pos[j].x && pos[i].y==pos[j].y+1) ||
                (pos[i].x==pos[j].x && pos[i].y==pos[j].y-1) ||
                (pos[i].x==pos[j].x+1 && pos[i].y==pos[j].y) ||
                (pos[i].x==pos[j].x-1 && pos[i].y==pos[j].y) 
            )
            ++x;
            if(
                (pos[i].x==pos[j].x+1 && pos[i].y==pos[j].y+1) ||
                (pos[i].x==pos[j].x-1 && pos[i].y==pos[j].y-1) ||
                (pos[i].x==pos[j].x+1 && pos[i].y==pos[j].y-1) ||
                (pos[i].x==pos[j].x-1 && pos[i].y==pos[j].y+1) 
            )
            ++y;
        }
        if(x==4) ans[y]++;
    }
    for(int k=0;k<5;++k)
        cout<<ans[k]<<endl;
    return 0;
}
