//�����������Ĳ����ɾ��
#include <iostream>
#include <algorithm>
using namespace std;

typedef int KeyType;

typedef struct node
{
    KeyType key;
    struct node *lchild,*rchild;
}*BST,BiTree;

BST searchBST(BST T,KeyType key)
{
    if(!T) return NULL;
    else if(T->key==key) return T;
    else if(T->key<key) return searchBST(T->rchild,key);
    else searchBST(T->lchild,key);
}   

BST insertBST(BST T,KeyType key)
{
    if(!T)
    {
        T = new BiTree;
        T->key = key;
        T->lchild = T->rchild = NULL;
        return T;
    }
    else if(T->key==key) return T;//�������
    else if(T->key>key) T->lchild = insertBST(T->lchild,key);
    else T->rchild = insertBST(T->rchild,key);
    return T;
}

BST CreateBST(int n)
{
    BST T = NULL;
    KeyType key;
    for(int i=1;i<=n;++i)
    {
        cin>>key;
        T = insertBST(T,key);
    }
    return T;
}

BST DeleteBST(BST T,KeyType key)
{
    BST p = T;
    BST parent = NULL;
    BST f,q;
    while(p)
    {
        if(p->key == key) break;
        else if(p->key < key)
        {
            parent = p;
            p = p->rchild;
        }
        else
        {
            parent = p;
            p = p->lchild;
        }
    }
    if(!p) return T;//û�ҵ�,���ظ��ڵ�

    //��һ�������p��Ҷ�ӽڵ�
    if(!p->rchild && !p->lchild)
    {
        if(parent)//������ڵ����
        {
            if(parent->key<key) parent->rchild = NULL;
            else parent->lchild = NULL;
            free(p);
            return T;
        }
        else
        {
            free(p);
            return NULL;
        }
    }

    //�ڶ��������pֻ���Һ���
    else if(!p->lchild && p->rchild)
    {
        if(parent)
        {
            if(parent->key<key) parent->rchild = p->rchild;
            else parent->lchild = p->rchild;
            free(p);
            return T;
        }
        else
        {
            T = p->rchild;
            free(p);
            return T;
        }
    }

    //�����������pֻ������
    else if(p->lchild && !p->rchild)
    {
        if(parent)
        {
            if(parent->key<key) parent->rchild = p->lchild;
            else parent->lchild = p->lchild;
            free(p);
            return T;
        }
        else
        {
            T = p->lchild;
            free(p);
            return T;
        }
    }

    //�����������p�������������Һ���
    else
    {
        f =p;//f��q�ĸ��ڵ�
        q = p->lchild;
        while(q->rchild)
        {
            f = q;
            q = q->rchild;
        }
        p->key = q->key;
        if(!q->rchild && !q->lchild)
        {
            if(f->key < q->key)
                f->rchild = NULL;
            else
                f->lchild = NULL;
            free(q);
        }
        else
        {
            if(f->key < q->key)
            {
                f->rchild = q->lchild;
            }
            else
            {
                f->lchild = q->lchild;
            }
        }
        return T;
    }
}

void InOrderTraverse(BST T)
{
    if(T)
    {
        InOrderTraverse(T->lchild);
        cout<<T->key<<" ";
        InOrderTraverse(T->rchild);
    }
}

int main()
{
    BST T;
    int n;
    cout<<"��ʼ����ƽ�������!"<<endl;
    cout<<"������ڵ������";
    cin>>n;
    cout<<"��������Щ�ڵ㣺"<<endl;
    T = CreateBST(n);
    while(1)
    {
        cout<<"֧�ֹ��ܣ�"<<endl;
        cout<<"1.����ڵ�"<<endl;
        cout<<"2.ɾ���ڵ�"<<endl;
        cout<<"3.�������BST"<<endl;
        cout<<"---------------"<<endl;
        cout<<"����������Ҫʹ�õĹ��ܣ�"<<endl;
        int c;cin>>c;
        switch(c)
        {
            case 1:
                cout<<"��������Ҫ����Ľڵ��ֵ��"<<endl;
                KeyType k;
                cin>>k;
                insertBST(T,k);
                cout<<"����ɹ���"<<endl;
                system("pause");
                system("cls");
                break;
            case 2:
                cout<<"��������Ҫɾ���Ľڵ��ֵ��"<<endl;
                KeyType k1;
                cin>>k1;
                if(searchBST(T,k1)==NULL)
                {
                    cout<<"�Ҳ����ýڵ㣡"<<endl;
                }
                else
                {
                    T = DeleteBST(T,k1);
                    cout<<"ɾ���ɹ���"<<endl;
                }
                system("pause");
                system("cls");
                break;
            case 3:
                InOrderTraverse(T);
                cout<<endl;
                system("pause");
                system("cls");
                break;
            default:
                exit(0);
        }
    }
    return 0;
}