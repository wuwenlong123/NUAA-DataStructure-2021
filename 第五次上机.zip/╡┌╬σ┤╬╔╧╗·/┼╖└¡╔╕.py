l,r = list(map(lambda x:int(x),input().split(',')))
from math import *

def ouler(x):
    vis = [0 for i in range(x+1)]
    p_table = []
    ln = 0
    for num in range(2,x+1):
        if vis[num] == 0:
            p_table.append(num)
            ln += 1
        for j in range(ln):
            if num*p_table[j] > x:
                break
            vis[num*p_table[j]] = 1
            if num*p_table[j] == 0:
                break
    return p_table

prime_table = ouler(10000)

def is_prime(x):
    if x == 1:
        return False
    for i in prime_table:
        if i*i > x:
            return True
        if x%i == 0:
            return False

ans = []
for i in range(l,r+1):
    if is_prime(i):
        ans.append(i)
print(ans)

