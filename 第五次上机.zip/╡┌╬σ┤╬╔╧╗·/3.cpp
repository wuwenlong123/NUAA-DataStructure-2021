#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 601;
int a[N][N], prefixsum[N][N];

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(NULL),cout.tie(NULL);
    int n,L,r,t;
    cin>>n>>L>>r>>t;
    memset(prefixsum, 0, sizeof prefixsum);//初始化prefix矩阵
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++) 
        {
            cin >> a[i][j];
            prefixsum[i][j] = prefixsum[i][j - 1] + a[i][j];//差分，计算每一行的前缀和
        }

    int count = 0;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++) 
        {
            int left = (j - r < 1) ? 1 : j - r;//左边界
            int right = (j + r > n) ? n : j + r;//右边界
            int up = (i - r < 1) ? 1 : i - r;//上边界
            int down = (i + r > n) ? n : i + r;//下边界
            int sum = 0;//范围内的像素和
            for (int k = up; k <= down; k++)
            //因为每一行的前缀和都已经计算过了，就在列上累加
                sum += prefixsum[k][right] - prefixsum[k][left - 1];//右边界的前缀和-左边界的前缀和
            if (sum <= (down - up + 1) * (right - left + 1) * t) count++;
        }
    cout << count << endl;
    return 0;
}