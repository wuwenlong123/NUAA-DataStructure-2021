#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

typedef struct list1
{
    int data;
    list1* next;
}list1;

int main()
{
    cout<<"1"<<endl;
    printf("1\n");
    return 0;
}